# XAUUSD Manual Strategy — Data and Research

Purpose: reproducible research toward a **manual** XAUUSD trading strategy. Historical data are not proof of live tradability.

## Data hierarchy

- `research/01_reaction_zones_3x_m15_atr14/primary/`: canonical catalog of 2,091 completed reversal legs, linked feature observations, timeframe snapshots, and event descriptions.
- `context/`: FVG and liquidity observation tables; preserve missing event IDs and overlap.
- `raw/`: M1 bid OHLC source data.
- `historical_backtest_not_validated/`: archival strategy candidate output only. **Do not treat past reported PnL/WR as validated.**
- `FILE_MANIFEST.csv`: exact SHA256, rows, size, and event-id coverage for each source.

## Definitions and scope

- Reversal catalog: M1 price extremes whose completed price movement is at least **3 × ATR(14) of M15**, evaluated with the catalog's ATR values.
- 2,091 unique event IDs, 1,047 LONG and 1,044 SHORT. The smallest recorded `movement_atr` is 3.0061.
- Sessions in archived dataset: Asia 470, London 440, New York 514, Outside 667.
- These are **retrospectively labeled successful movements**, not unbiased prospective trade signals. Do not backtest by entering at an event origin selected with hindsight.
- Timestamp labels marked `utc3` mean fixed UTC+3; Israel local clocks vary seasonally.
- Historic backtests must be re-audited for causal signal availability, next-bar execution, tie-breaks, spreads, stop/TP chronology, 120-minute forced exits, position overlap, holdout, and costs.

## Research targets (requirements, not achieved results)

- Only entry during London 09:00–12:00 UTC+3 and NY 16:30–18:30 UTC+3.
- Each trade closed within 120 minutes of entry.
- At least one trade on 90% of eligible trading days.
- Average realized net R/trade >= +1 (approximately +10R per 10 trades), validated on untouched out-of-sample data.
- Entries, stops, and take profits may be optimized; no mandatory win rate or RR.

## Integrity limitations

- SHA256 and cross-table event ID checks establish **file integrity and internal relationships**, not the economic correctness of all feature construction.
- Existing historical candidate metrics should not be represented as verified or forward-test-ready.
- All future experimental results should include exact code commit, input data SHA256, methodology, number of trades, missing trade days, and train/holdout periods.
